
constructor(){

//Obtenemos mediante el fetch los datos de la API

    fetch("link")
    .then(response => response.json())
    .then (series => {
        series.forEach((element: any)=>{
            let serie = element as ISerie;
            this.arrSeries.push(serie);
         });
    }
    
    );
}

getAllSeries(): ISerie[]{
    return this.arrSeries;
}


Ir al *series-list*

arrSeries: ISerie[] = [];
seriesService = inject(SeriesServiceService)

ngOnInit(){
    this.arrSeries = this.seriesService.getAllSeries();
}

http://jsonblob.com/api/1333093452690415616