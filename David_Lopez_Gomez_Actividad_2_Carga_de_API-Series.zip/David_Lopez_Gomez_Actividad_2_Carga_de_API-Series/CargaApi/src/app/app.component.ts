import { Component } from '@angular/core';

import { ProductListComponent } from "./components/product-list/product-list.component";
import { ProductFormComponent } from "./components/product-form/product-form.component";
import { FormsModule } from '@angular/forms';






@Component({
  selector: 'app-root',
  imports: [ProductListComponent, ProductFormComponent, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'CargaApi';
}
