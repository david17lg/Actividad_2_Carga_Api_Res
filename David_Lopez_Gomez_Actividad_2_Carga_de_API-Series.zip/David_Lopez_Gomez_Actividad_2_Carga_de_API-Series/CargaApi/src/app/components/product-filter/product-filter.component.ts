import { Component, inject } from '@angular/core';
import { FormsModule, NgForm} from '@angular/forms';
import { IProducto } from '../../interfaces/iproducto';
import { ProdsService } from '../../services/prods.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-productfilter',
  imports: [FormsModule, CommonModule],
  templateUrl: './product-filter.component.html',
  styleUrl: './product-filter.component.css'
})
export class ProductFilterComponent {
    
    productos: IProducto[];
    
    prodsService = inject(ProdsService);

    categories: string[];

    state: boolean = false;
   

    
    constructor() {
      this.productos = [];
      this.categories = ["Hombre", "Mujer", "Niño",];
    

      
    }

    ngOnInit(): void {
      this.productos = this.prodsService.getAllProducts();
    }

   
    getDataFilter(miForm: NgForm) {
      const filters = miForm.value;
      console.log('Filtro aplicado:', filters);
    }

    

   
   

    

   

}
