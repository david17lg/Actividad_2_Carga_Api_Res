import { Component } from '@angular/core';
import { IProducto } from '../../interfaces/iproducto';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-product-form',
  imports: [ReactiveFormsModule],
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css'
})
export class ProductFormComponent {

  arrProductos: IProducto[];
  modelForm: FormGroup<any>;
  isNewProd: boolean = true;



  constructor() {
    this.modelForm = new FormGroup({
      name: new FormControl(null, [Validators.required, Validators.minLength(3)]),
      price: new FormControl(null, [Validators.required, Validators.pattern("^(?!0(?:[.,]0+)?$)(?:[1-9]\\d*|0?[.,]\\d+)$")]),
      category: new FormControl(null, Validators.required),
      description: new FormControl(null, [Validators.required, Validators.minLength(10)]),
    });
    this.arrProductos = [];
  }

  getDataForm() {
    let producto: IProducto = this.modelForm.value as IProducto;
    this.arrProductos.push(producto);
    console.log(this.arrProductos);
    this.modelForm.reset();

  }

  checkControl(formControlName: string, validador: string): boolean | undefined{
    return this.modelForm.get(formControlName)?.hasError(validador) &&
    this.modelForm.get(formControlName)?.touched;
  }

  

}

