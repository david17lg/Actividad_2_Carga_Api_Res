import { IProducto } from '../../interfaces/iproducto';
import { ProdsService } from './../../services/prods.service';
import { Component, inject, Input } from '@angular/core';

@Component({
  selector: 'app-product-card',
  imports: [],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.css'
})
export class ProductCardComponent {

  ProdsService = inject(ProdsService);

  @Input() miProducto!: IProducto;

  deleteProd(producto:  IProducto) {
    this.ProdsService.deleteByTitle(producto.name);
  }

  toUpperCase(text: string): string {
    return text.toUpperCase();
  }


  


}
