import { Component, inject } from '@angular/core';
import { ProdsService } from '../../services/prods.service';
import { IProducto } from '../../interfaces/iproducto';
import { ProductCardComponent } from "../product-card/product-card.component";
import { ProductFilterComponent } from "../product-filter/product-filter.component";



@Component({
  selector: 'app-product-list',
  imports: [ProductCardComponent, ProductFilterComponent],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {

  arrProductos: IProducto[] = [];
  prodsService = inject(ProdsService);

ngOnInit(): void {
  this.arrProductos = this.prodsService.getAllProducts();
  console.log(this.arrProductos);

}

}
