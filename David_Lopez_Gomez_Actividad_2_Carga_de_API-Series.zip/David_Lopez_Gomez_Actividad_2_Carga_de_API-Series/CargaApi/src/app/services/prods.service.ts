import { Injectable } from '@angular/core';
import { IProducto } from '../interfaces/iproducto';


@Injectable({
  providedIn: 'root'
})
export class ProdsService {

  private arrProductos: IProducto[];

  constructor() {

    this.arrProductos = [];
  

    fetch("https://jsonblob.com/api/1333093452690415616")
    .then(response => response.json())
    .then(productos => {
      productos.forEach((element: any) => {
        let producto = element as IProducto;
        this.arrProductos.push(producto);  
      });
    });

    console.log("Los productos cargados son: ", this.arrProductos);
    

  }

  getAllProducts(): IProducto[] {
    return this.arrProductos;
  }

  deleteByTitle(title: string): IProducto[] {
    let i = this.arrProductos.findIndex((producto) => producto.name == title);
    if(i != -1 && i >= 0 && i < this.arrProductos.length) {
      this.arrProductos.splice(i, 1);
    }
    return this.arrProductos;
  }

 
}
